## Commands to run 
```python
python3 pacman.py -p ClassifierAgent
```
