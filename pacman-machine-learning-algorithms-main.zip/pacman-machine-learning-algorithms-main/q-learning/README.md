## Commands to run

```python

python3 pacman.py -p QLearnAgent -x 2000 -n 2010 -l smallGrid

```
